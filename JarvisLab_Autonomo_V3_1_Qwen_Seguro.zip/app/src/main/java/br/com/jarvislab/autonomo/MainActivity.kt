package br.com.jarvislab.autonomo

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.IBinder
import android.os.StatFs
import android.provider.OpenableColumns
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import com.tensai.llamakt.ChatMessage
import com.tensai.llamakt.LlamaEngine
import com.tensai.llamakt.SamplingParams
import com.tensai.llamakt.chat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val prefs by lazy { getSharedPreferences("jarvis_data", MODE_PRIVATE) }
    private val modelPath by lazy { File(filesDir, "qwen.gguf") }
    private var qwen: LlamaEngine? = null
    private var loaded = false
    private var modelTask: Job? = null
    private val busy = AtomicBoolean(false)
    private val history = mutableListOf<ChatMessage>()
    private var tts: TextToSpeech? = null
    private var adbService: IAdbService? = null
    private var adbBound = false
    private val adbActions = setOf("modelo", "android", "aplicativos", "tela", "inicio", "voltar")

    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        event("adb", if (result == PackageManager.PERMISSION_GRANTED) "Permissão autorizada. Toque novamente na ação." else "Permissão Shizuku negada.")
    }
    private val adbConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            adbService = IAdbService.Stub.asInterface(binder)
            adbBound = true
            event("adb", "Shizuku conectado: comandos ADB permitidos disponíveis.")
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            adbBound = false
            adbService = null
            event("adb", "Shizuku desconectado.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 13, 19)
        window.navigationBarColor = android.graphics.Color.rgb(9, 13, 19)
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(9, 13, 19))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) = loader.shouldInterceptRequest(request.url)
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                    request.url.toString() != "https://appassets.androidplatform.net/assets/index.html"
            }
            addJavascriptInterface(Bridge(), "JarvisAndroid")
            loadUrl("https://appassets.androidplatform.net/assets/index.html")
        }
        setContentView(web)
        try { Shizuku.addRequestPermissionResultListener(shizukuListener) } catch (_: Exception) { }
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("pt", "BR")
        }
    }

    private fun event(type: String, message: String, extra: JSONObject? = null) {
        val obj = JSONObject().put("type", type).put("message", message)
        if (extra != null) obj.put("data", extra)
        val payload = JSONObject.quote(obj.toString())
        runOnUiThread { web.evaluateJavascript("window.jarvisNative($payload)", null) }
    }

    private fun snapshot(): JSONObject {
        val memory = (getSystemService(ACTIVITY_SERVICE) as ActivityManager).let {
            val info = ActivityManager.MemoryInfo(); it.getMemoryInfo(info)
            JSONObject().put("total", info.totalMem).put("livre", info.availMem)
                .put("percent", ((info.totalMem - info.availMem) * 100.0 / info.totalMem).toInt())
        }
        val stat = StatFs(filesDir.absolutePath)
        val total = stat.totalBytes; val free = stat.availableBytes
        val battery = (getSystemService(BATTERY_SERVICE) as BatteryManager)
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return JSONObject()
            .put("ram", memory)
            .put("armazenamento", JSONObject().put("total", total).put("livre", free).put("percent", ((total - free) * 100.0 / total).toInt()))
            .put("bateria", battery)
            .put("modelo", if (modelPath.exists()) "GGUF: ${(modelPath.length() / 1048576)} MB" else "Nenhum modelo GGUF importado")
            .put("modeloCarregado", loaded)
            .put("modeloImportado", modelPath.isFile && modelPath.length() >= 16L * 1024 * 1024)
            .put("shizuku", adbBound)
            .put("chaveDeepSeek", getApiKey().isNotBlank())
            .put("tarefas", JSONArray(prefs.getString("tarefas", "[]")))
            .put("notas", JSONArray(prefs.getString("notas", "[]")))
    }

    inner class Bridge {
        @JavascriptInterface fun status() { event("estado", "", snapshot()) }
        @JavascriptInterface fun selecionarModelo() = runOnUiThread {
            val it = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            startActivityForResult(it, 1001)
        }
        @JavascriptInterface fun selecionarArquivo() = runOnUiThread {
            val it = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            startActivityForResult(it, 1002)
        }
        @JavascriptInterface fun ouvir() = runOnUiThread {
            try {
                val it = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                startActivityForResult(it, 1003)
            } catch (_: Exception) { event("erro", "Reconhecimento de voz indisponível neste aparelho.") }
        }
        @JavascriptInterface fun falar(texto: String) = runOnUiThread {
            tts?.speak(texto.take(1000), TextToSpeech.QUEUE_FLUSH, null, "jarvis-fala")
        }
        @JavascriptInterface fun definirChave(chave: String) {
            try {
                if (chave.isBlank()) { prefs.edit().remove("apiSecret").remove("apiIv").apply(); event("info", "Chave removida.") }
                else { saveApiKey(chave.trim()); event("info", "Chave DeepSeek guardada no Android Keystore.") }
                event("estado", "", snapshot())
            } catch (_: Exception) { event("erro", "Falha ao proteger a chave da API.") }
        }
        @JavascriptInterface fun salvar(tipo: String, raw: String) {
            if (tipo !in setOf("tarefas", "notas") || raw.length > 150000) return
            try {
                val arr = JSONArray(raw)
                if (arr.length() > 200) throw IllegalArgumentException()
                prefs.edit().putString(tipo, arr.toString()).apply()
                event("estado", "", snapshot())
            } catch (_: Exception) { event("erro", "Dados inválidos para salvar.") }
        }
        @JavascriptInterface fun perguntar(modo: String, pergunta: String) {
            val txt = pergunta.trim()
            if (txt.isEmpty() || txt.length > 1500) { event("erro", "Mensagem inválida (máx. 1500 caracteres)."); return }
            if (modo !in setOf("qwen", "deepseek")) { event("erro", "Motor de IA inválido."); return }
            // V3.1: não entra no motor nativo sem um GGUF válido e RAM suficiente.
            if (modo == "qwen" && !loaded) {
                val reason = qwenPreflight()
                if (reason != null) { event("erro", "Qwen: $reason"); return }
            }
            if (!busy.compareAndSet(false, true)) { event("erro", "Aguarde a resposta anterior."); return }
            if (modo == "deepseek") {
                scope.launch {
                    try { event("resposta", deepSeek(txt)) }
                    catch (e: Exception) { event("erro", "DeepSeek: " + safeError(e)) }
                    finally { busy.set(false) }
                }
            } else {
                modelTask = scope.launch {
                    try { runQwen(txt) }
                    catch (e: OutOfMemoryError) {
                        Log.e("JarvisQwen", "Memoria insuficiente na execucao Qwen", e)
                        event("erro", "Qwen: memória insuficiente. Use um GGUF menor e feche aplicativos em segundo plano.")
                    } catch (e: LinkageError) {
                        Log.e("JarvisQwen", "Falha na biblioteca nativa Qwen", e)
                        event("erro", "Qwen: falha na biblioteca nativa. Verifique o registro do Android.")
                    } catch (e: Exception) {
                        Log.e("JarvisQwen", "Excecao ao executar Qwen", e)
                        event("erro", "Qwen: " + safeError(e))
                    } finally { busy.set(false) }
                }
            }
        }
        @JavascriptInterface fun solicitarAdb(acao: String) = runOnUiThread {
            if (acao !in adbActions) { event("erro", "Ação ADB bloqueada."); return@runOnUiThread }
            val confirmation = if (acao == "inicio" || acao == "voltar") "Isso mudará a tela do Android." else "Isso consultará dados do seu aparelho."
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Autorizar comando ADB: $acao?")
                .setMessage(confirmation + " O comando só será executado após sua confirmação.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Executar") { _, _ -> doAdb(acao) }
                .show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        if (requestCode == 1003) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
            event("voz", text)
        } else if (requestCode == 1002) {
            val uri = data?.data ?: return
            val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) c.getString(i) else null
            } ?: "Arquivo selecionado"
            event("arquivo", "Selecionado: $name (sem leitura automática)")
        } else if (requestCode == 1001) {
            val uri = data?.data ?: return
            scope.launch {
                event("modelo", "Importando GGUF para o armazenamento privado do aplicativo...")
                try {
                    val size = withContext(Dispatchers.IO) {
                        val dst = File(filesDir, "qwen.tmp")
                        try {
                            contentResolver.openInputStream(uri)?.use { input ->
                                dst.outputStream().use { output -> input.copyTo(output, 256 * 1024) }
                            } ?: error("Não foi possível abrir o modelo.")
                            dst.inputStream().use { stream ->
                                val magic = ByteArray(4)
                                if (stream.read(magic) != 4 || String(magic, StandardCharsets.US_ASCII) != "GGUF") error("O arquivo não é um modelo GGUF.")
                            }
                            if (loaded) { qwen?.free(); qwen = null; loaded = false; history.clear() }
                            if (modelPath.exists()) modelPath.delete()
                            if (!dst.renameTo(modelPath)) error("Não foi possível mover o modelo.")
                            modelPath.length() / 1048576
                        } finally { dst.delete() }
                    }
                    event("modelo", "Modelo GGUF importado ($size MB). Agora abra Chat → Qwen.")
                    event("estado", "", snapshot())
                } catch (e: Exception) { event("erro", "Importação: " + safeError(e)) }
            }
        }
    }

    // Conservador: a carga nativa não pode ser recuperada se o Android matar o processo por RAM.
    private fun qwenPreflight(): String? {
        if (!modelPath.isFile) return "Importe primeiro um modelo GGUF em Configurações."
        val size = modelPath.length()
        if (size < 16L * 1024 * 1024) return "Arquivo GGUF incompleto ou inválido. Importe novamente."
        val mem = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mem)
        val required = (size * 1.15 + 384.0 * 1024 * 1024).toLong()
        if (mem.availMem < required) return "Memória disponível baixa para este GGUF. Feche outros aplicativos ou use Qwen 0.5B Q4_K_M."
        return null
    }

    private suspend fun runQwen(msg: String) {
        qwenPreflight()?.takeIf { !loaded }?.let { throw IllegalStateException(it) }
        if (!modelPath.exists()) throw IllegalStateException("Importe primeiro um Qwen GGUF em Configurações.")
        if (!loaded) {
            event("info", "Carregando o Qwen no celular (sem Termux e sem internet)...")
            withContext(Dispatchers.Default) {
                qwen?.free()
                Log.i("JarvisQwen", "Carregando GGUF no modo CPU; nCtx=1024")
                qwen = LlamaEngine().also { it.load(modelPath.absolutePath, nGpuLayers = 0, nCtx = 1024, kvCacheType = "q8_0") }
                loaded = true
            }
            event("modelo", "Qwen carregado no próprio Android.")
        }
        val conversation = (history.takeLast(8) + ChatMessage("user", msg))
        val answer = StringBuilder()
        var lastSent = 0L
        qwen!!.chat(conversation, SamplingParams(nPredict = 256), enableThinking = false).collect { tok ->
            answer.append(tok)
            if (System.currentTimeMillis() - lastSent > 150) {
                event("fluxo", answer.toString())
                lastSent = System.currentTimeMillis()
            }
        }
        val finalText = answer.toString().trim()
        if (finalText.isBlank()) throw IllegalStateException("O modelo não retornou texto.")
        history.add(ChatMessage("user", msg))
        history.add(ChatMessage("assistant", finalText))
        if (history.size > 12) history.subList(0, history.size - 12).clear()
        event("resposta", finalText)
        event("estado", "", snapshot())
    }

    private suspend fun deepSeek(msg: String): String = withContext(Dispatchers.IO) {
        val secret = getApiKey()
        if (secret.isBlank()) throw IllegalStateException("Adicione sua chave DeepSeek em Configurações.")
        val payload = JSONObject().put("model", "deepseek-flash")
            .put("thinking", JSONObject().put("type", "disabled"))
            .put("stream", false).put("max_tokens", 650)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", "Você é Jarvis, assistente em português. Responda apenas texto; não execute ações nem solicite dados pessoais."))
                .put(JSONObject().put("role", "user").put("content", msg)))
        val conn = (URL("https://api.deepseek.com/chat/completions").openConnection() as HttpURLConnection)
        try {
            conn.requestMethod = "POST"; conn.connectTimeout = 15000; conn.readTimeout = 65000
            conn.setRequestProperty("Authorization", "Bearer $secret")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            conn.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
            if (conn.responseCode != 200) throw IllegalStateException("HTTP ${conn.responseCode}. Confira a chave, saldo e conexão.")
            val body = conn.inputStream.bufferedReader().use { it.readText().take(250000) }
            JSONObject(body).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").take(12000)
        } finally { conn.disconnect() }
    }

    private fun doAdb(action: String) {
        try {
            if (!Shizuku.pingBinder()) { event("erro", "Instale e inicie o Shizuku via Depuração sem fio para usar comandos ADB."); return }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(4544)
                event("adb", "Autorize o Jarvis no Shizuku e toque na ação novamente.")
                return
            }
            if (adbService == null) {
                val args = Shizuku.UserServiceArgs(ComponentName(this, AdbShellService::class.java))
                    .daemon(false).processNameSuffix("jarvis_adb").debuggable(false).version(1)
                Shizuku.bindUserService(args, adbConnection)
                event("adb", "Conectando serviço ADB. Toque novamente na ação após conectar.")
                return
            }
            scope.launch(Dispatchers.IO) {
                try { event("adb", adbService!!.executar(action).take(30000)) }
                catch (e: Exception) { event("erro", "ADB falhou: " + safeError(e)) }
            }
        } catch (_: Exception) { event("erro", "Shizuku não está disponível ou não iniciou.") }
    }

    private fun keyStoreKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getKey("jarvis_deepseek", null) as? SecretKey
        if (existing != null) return existing
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").run {
            init(KeyGenParameterSpec.Builder("jarvis_deepseek", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
            generateKey()
        }
    }
    private fun saveApiKey(secret: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, keyStoreKey())
        val ciphertext = cipher.doFinal(secret.toByteArray(StandardCharsets.UTF_8))
        prefs.edit().putString("apiSecret", Base64.encodeToString(ciphertext, Base64.NO_WRAP))
            .putString("apiIv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP)).apply()
    }
    private fun getApiKey(): String {
        return try {
            val secret = prefs.getString("apiSecret", null) ?: return ""
            val iv = prefs.getString("apiIv", null) ?: return ""
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, keyStoreKey(), GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
            String(cipher.doFinal(Base64.decode(secret, Base64.NO_WRAP)), StandardCharsets.UTF_8)
        } catch (_: Exception) { "" }
    }

    private fun safeError(e: Throwable): String = when (e) {
        is OutOfMemoryError -> "Memória insuficiente. Experimente um Qwen quantizado menor."
        else -> (e.message ?: e.javaClass.simpleName).take(240).replace(Regex("sk-[\\w-]+"), "[chave oculta]")
    }
    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(shizukuListener) } catch (_: Exception) { }
        try { qwen?.interrupt() } catch (_: Exception) { }
        modelTask?.cancel()
        scope.cancel()
        tts?.stop(); tts?.shutdown()
        web.removeJavascriptInterface("JarvisAndroid")
        web.destroy()
        super.onDestroy()
    }
}
