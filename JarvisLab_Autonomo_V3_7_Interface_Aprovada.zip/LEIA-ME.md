# JARVIS LAB V3.7 — Interface aprovada (grafite e azul-acinzentado)

Este pacote atualiza o visual do JARVIS LAB V3.6. A base nativa das três inteligências e das funções de automação permanece a mesma.

## Mudanças visuais

- Tela inicial: um único círculo com 8 ícones distribuídos radialmente e um emblema discreto JARVIS LAB no centro.
- Cores: grafite, azul-acinzentado e brilho discreto; não usa neon intenso.
- Indicadores: bateria, RAM e armazenamento. Para RAM/armazenamento, o Android envia os totais e volumes disponíveis. A interface calcula quanto está em uso, exibe percentual, quantidade usada/total e barra proporcional.
- Chat: cartões arredondados, barra de entrada tipo cápsula, microfone SVG branco *sem anel*, botão azul para enviar, navegação inferior com ícones vetoriais.
- Removido o texto explicativo que aparecia abaixo das mensagens no chat e a faixa informativa abaixo dos indicadores da página inicial. O histórico salvo não é apagado.
- Todas as oito seções de menu, assim como navegação e botões, continuam conectadas aos eventos JavaScript existentes.

## Funções mantidas da V3.6

- Gemma 3 1B LiteRT-LM CPU, offline depois de importar o `.litertlm`.
- Qwen 1.5B GGUF local, em processo isolado.
- DeepSeek por API HTTPS com chave no Android Keystore.
- Memória persistente, histórico de conversa, notas e tarefas.
- Comandos por voz por toque e síntese de fala (dependem dos serviços Android disponíveis).
- Abrir aplicativos por comando sem ADB/Shizuku; operações ADB avançadas opcionais com autorização.

## Compilação com GitHub Actions

1. No repositório GitHub `JarvisLab-Android`, envie o arquivo `JarvisLab_Autonomo_V3_7_Interface_Aprovada.zip` à **raiz**.
2. Crie `.github/workflows/build-jarvis-v37.yml` e cole o conteúdo do arquivo `build-jarvis-v37.yml` fornecido separadamente.
3. Vá a **Actions > JARVIS V3.7 Interface Aprovada | Gemma3 + Qwen + DeepSeek > Run workflow**.
4. Se o workflow for concluído, baixe o artefato `JarvisLab-V3.7-Interface-Aprovada-APK`, extraia `app-debug.apk` e instale-o no Android.

## Antes de instalar

A V3.7 usa o `applicationId` separado `br.com.jarvislab.autonomo.v37`, para preservar a V3.6 e evitar conflitos de assinatura entre builds de depuração. Portanto, **dados privados da V3.6 não são transferidos automaticamente**: é necessário importar os arquivos de modelo novamente na V3.7; memórias, tarefas, notas e configurações da V3.6 permanecem no aplicativo antigo. A remoção da V3.6 pode apagar seus dados privados; não a desinstale antes de verificar a nova versão.

## Limites dos testes

Esta entrega é código-fonte e workflow; **não é um APK compilado**. A sintaxe JavaScript/HTML e os cliques/estados de telas foram verificados numa prévia em Chromium. A compilação Android completa, integração LiteRT-LM e execução em aparelho dependem da etapa GitHub Actions e de testes no Android. As porcentagens das imagens de prévia são valores de demonstração, não medições do celular.
