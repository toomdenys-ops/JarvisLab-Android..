package br.com.jarvislab.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private static final String START_URL = "http://127.0.0.1:8081/";
    private static final int MICROPHONE_REQUEST = 100;
    private static final int FILES_REQUEST = 101;

    private FrameLayout frame;
    private WebView webView;
    private WebView popupWebView;
    private LinearLayout disconnected;
    private PermissionRequest pendingAudioRequest;
    private ValueCallback<Uri[]> pendingFileChooser;
    private boolean mainLoadFailed;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(7, 12, 16));
        getWindow().setNavigationBarColor(Color.rgb(7, 12, 16));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        WebView.setWebContentsDebuggingEnabled(false);

        frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.rgb(5, 10, 14));
        setContentView(frame);

        webView = newWebView(true);
        frame.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        disconnected = buildDisconnectedView();
        frame.addView(disconnected, new FrameLayout.LayoutParams(-1, -1));
        disconnected.setVisibility(View.GONE);
        webView.loadUrl(START_URL);
    }

    private boolean isLocalAddress(String address) {
        try {
            Uri uri = Uri.parse(address);
            String host = uri.getHost();
            int port = uri.getPort();
            return "http".equalsIgnoreCase(uri.getScheme())
                && ("127.0.0.1".equals(host) || "localhost".equalsIgnoreCase(host))
                && (port == 8081 || port == 8766);
        } catch (Exception ignored) {
            return false;
        }
    }

    private void openOutside(String url) {
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme();
        if (!"https".equalsIgnoreCase(scheme) && !"mailto".equalsIgnoreCase(scheme)) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException ignored) { }
    }

    private WebView newWebView(boolean primary) {
        WebView page = new WebView(this);
        WebSettings s = page.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true); // uploads selected pelo seletor do Android
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);
        page.setBackgroundColor(Color.rgb(5, 10, 14));
        page.setOverScrollMode(View.OVER_SCROLL_NEVER);
        page.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (isLocalAddress(url)) return false;
                openOutside(url);
                return true;
            }
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (primary) mainLoadFailed = false;
            }
            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError error) {
                if (primary && req.isForMainFrame()) {
                    mainLoadFailed = true;
                    disconnected.setVisibility(View.VISIBLE);
                }
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                if (primary && !mainLoadFailed && disconnected != null) {
                    disconnected.setVisibility(View.GONE);
                }
            }
        });
        page.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermission(request));
            }
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
                pendingFileChooser = callback;
                try {
                    Intent i = params.createIntent();
                    startActivityForResult(i, FILES_REQUEST);
                    return true;
                } catch (Exception error) {
                    pendingFileChooser.onReceiveValue(null);
                    pendingFileChooser = null;
                    return false;
                }
            }
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog,
                                          boolean isUserGesture, Message resultMsg) {
                if (!isUserGesture) return false;
                if (popupWebView != null) closePopup();
                popupWebView = newWebView(false);
                frame.addView(popupWebView, new FrameLayout.LayoutParams(-1, -1));
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popupWebView);
                resultMsg.sendToTarget();
                return true;
            }
            @Override
            public void onCloseWindow(WebView window) {
                if (window == popupWebView) closePopup();
            }
        });
        return page;
    }

    private void handleWebPermission(PermissionRequest request) {
        if (!isLocalAddress(request.getOrigin().toString())) {
            request.deny();
            return;
        }
        boolean wantsAudio = false;
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) wantsAudio = true;
            else { request.deny(); return; }
        }
        if (!wantsAudio) { request.deny(); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            request.grant(new String[] { PermissionRequest.RESOURCE_AUDIO_CAPTURE });
        } else {
            pendingAudioRequest = request;
            requestPermissions(new String[] { Manifest.permission.RECORD_AUDIO }, MICROPHONE_REQUEST);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == MICROPHONE_REQUEST && pendingAudioRequest != null) {
            PermissionRequest req = pendingAudioRequest;
            pendingAudioRequest = null;
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED
                    && isLocalAddress(req.getOrigin().toString())) {
                req.grant(new String[] { PermissionRequest.RESOURCE_AUDIO_CAPTURE });
            } else req.deny();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILES_REQUEST && pendingFileChooser != null) {
            Uri[] files = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            pendingFileChooser.onReceiveValue(files);
            pendingFileChooser = null;
        }
    }

    private int dp(int n) { return (int)(getResources().getDisplayMetrics().density * n + 0.5f); }

    private LinearLayout buildDisconnectedView() {
        LinearLayout pane = new LinearLayout(this);
        pane.setBackgroundColor(Color.rgb(6, 12, 17));
        pane.setOrientation(LinearLayout.VERTICAL);
        pane.setGravity(Gravity.CENTER);
        pane.setPadding(dp(24), dp(24), dp(24), dp(24));
        TextView logo = new TextView(this);
        logo.setText("◉  JARVIS LAB");
        logo.setTextColor(Color.rgb(234, 247, 252));
        logo.setTextSize(30);
        logo.setGravity(Gravity.CENTER);
        pane.addView(logo, new LinearLayout.LayoutParams(-1, dp(80)));
        TextView label = new TextView(this);
        label.setText("Servidor Jarvis desconectado\n\nAbra o Termux e execute:\npython -u jarvis_agente_v90.py\n\nDepois toque em CONECTAR.");
        label.setTextColor(Color.rgb(187, 207, 218));
        label.setTextSize(16);
        label.setGravity(Gravity.CENTER);
        pane.addView(label, new LinearLayout.LayoutParams(-1, dp(160)));
        Button retry = new Button(this);
        retry.setText("CONECTAR");
        retry.setOnClickListener(v -> webView.loadUrl(START_URL));
        pane.addView(retry, new LinearLayout.LayoutParams(-1, dp(54)));
        Button termux = new Button(this);
        termux.setText("ABRIR TERMUX");
        termux.setOnClickListener(v -> {
            Intent launch = getPackageManager().getLaunchIntentForPackage("com.termux");
            if (launch != null) startActivity(launch);
        });
        pane.addView(termux, new LinearLayout.LayoutParams(-1, dp(54)));
        return pane;
    }

    private void closePopup() {
        if (popupWebView == null) return;
        frame.removeView(popupWebView);
        popupWebView.stopLoading();
        popupWebView.destroy();
        popupWebView = null;
    }

    @Override
    public void onBackPressed() {
        if (popupWebView != null) {
            if (popupWebView.canGoBack()) popupWebView.goBack();
            else closePopup();
        } else if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (pendingAudioRequest != null) pendingAudioRequest.deny();
        if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
        closePopup();
        webView.destroy();
        super.onDestroy();
    }
}
