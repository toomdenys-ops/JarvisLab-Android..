package br.com.jarvislab.autonomo

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.RemoteException
import android.util.Log
import com.tensai.llamakt.ChatMessage
import com.tensai.llamakt.LlamaEngine
import com.tensai.llamakt.SamplingParams
import com.tensai.llamakt.chat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.io.File

/** Processo separado do WebView. Crashes JNI não derrubam MainActivity. */
class QwenWorkerService : Service() {
    companion object {
        const val REQUEST_CHAT = 1
        const val EVENT_INFO = 2
        const val EVENT_LOADED = 3
        const val EVENT_STREAM = 4
        const val EVENT_RESULT = 5
        const val EVENT_ERROR = 6
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    // Apenas um GGUF permanece carregado no processo isolado por vez.
    private var engine: LlamaEngine? = null
    private var activeMotor: String? = null
    private val histories = mutableMapOf<String, MutableList<ChatMessage>>()

    private fun send(reply: Messenger, kind: Int, text: String) {
        val response = Message.obtain(null, kind)
        response.data = Bundle().apply { putString("text", text.take(12000)) }
        try { reply.send(response) } catch (_: RemoteException) { }
    }

    private val incoming by lazy {
        Messenger(Handler(Looper.getMainLooper()) { message ->
            if (message.what != REQUEST_CHAT) return@Handler true
            val reply = message.replyTo ?: return@Handler true
            val text = message.data.getString("text").orEmpty()
            val motor = message.data.getString("motor").orEmpty()
            if (motor !in setOf("gemma", "qwen")) {
                send(reply, EVENT_ERROR, "Modelo local inválido.")
                return@Handler true
            }
            if (text.isBlank() || text.length > 1500) {
                send(reply, EVENT_ERROR, "Mensagem inválida.")
            } else {
                scope.launch { answer(motor, text, reply) }
            }
            true
        })
    }

    override fun onBind(intent: Intent?): IBinder = incoming.binder

    private suspend fun answer(motor: String, text: String, reply: Messenger) {
        val label = if (motor == "gemma") "Gemma 4 E2B" else "Qwen"
        try {
            val file = File(filesDir, if (motor == "gemma") "gemma4.gguf" else "qwen.gguf")
            if (!file.isFile || file.length() < 16L * 1024 * 1024) {
                send(reply, EVENT_ERROR, "$label: importe primeiro um GGUF válido nas configurações.")
                return
            }
            if (activeMotor != motor) {
                // Fundamental em celulares com ~8GB de RAM: nunca manter dois modelos na memória.
                engine?.free()
                engine = null
                activeMotor = null
            }
            if (engine == null) {
                val gpu = motor == "gemma"
                send(reply, EVENT_INFO, "Carregando $label no processo isolado${if (gpu) " com GPU experimental" else ""}...")
                Log.i("JarvisLocalIA", "Carregando $motor, nCtx=1024, nGpuLayers=${if (gpu) 99 else 0}")
                val created = LlamaEngine()
                try {
                    // Gemma 4 E2B é excessivamente lento no caminho CPU atual do llama.kt.
                    // GPU pode não funcionar em todos os Androids: processo isolado protege a interface.
                    created.load(file.absolutePath, nGpuLayers = if (gpu) 99 else 0, nCtx = 1024, kvCacheType = "q8_0")
                } catch (error: Throwable) {
                    runCatching { created.free() }
                    throw error
                }
                engine = created
                activeMotor = motor
                send(reply, EVENT_LOADED, "$label carregado")
            }
            val history = histories.getOrPut(motor) { mutableListOf() }
            val conversation = history.takeLast(6) + ChatMessage("user", text)
            val output = StringBuilder()
            var lastSent = 0L
            engine!!.chat(conversation, SamplingParams(nPredict = if (motor == "gemma") 160 else 256), enableThinking = false).collect { token ->
                output.append(token)
                if (System.currentTimeMillis() - lastSent > 300) {
                    send(reply, EVENT_STREAM, output.toString())
                    lastSent = System.currentTimeMillis()
                }
            }
            val result = output.toString().trim()
            if (result.isBlank()) error("O modelo retornou resposta vazia.")
            history.add(ChatMessage("user", text))
            history.add(ChatMessage("assistant", result))
            if (history.size > 10) history.subList(0, history.size - 10).clear()
            send(reply, EVENT_RESULT, result)
        } catch (e: Exception) {
            Log.e("JarvisLocalIA", "Falha em $label", e)
            send(reply, EVENT_ERROR, "$label: " + (e.message ?: e.javaClass.simpleName).take(200))
        } catch (e: OutOfMemoryError) {
            Log.e("JarvisLocalIA", "Sem RAM em $label", e)
            send(reply, EVENT_ERROR, "$label: memória insuficiente. Selecione Qwen ou libere RAM.")
        } catch (e: LinkageError) {
            Log.e("JarvisLocalIA", "Biblioteca JNI em $label", e)
            send(reply, EVENT_ERROR, "$label: biblioteca nativa incompatível. Selecione Qwen.")
        }
    }

    override fun onDestroy() {
        scope.cancel()
        runCatching { engine?.free() }
        engine = null
        super.onDestroy()
    }
}
