package br.com.jarvislab.autonomo

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.os.Messenger
import android.os.Message
import android.os.RemoteException
import android.os.StatFs
import android.provider.OpenableColumns
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.io.File
import java.text.Normalizer
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val prefs by lazy { getSharedPreferences("jarvis_data", MODE_PRIVATE) }
    private fun modelFile(motor: String): File = File(filesDir, when (motor) {
        "gemma" -> "gemma4.gguf"
        "gemma3" -> "gemma3_1b.litertlm"
        else -> "qwen.gguf"
    })
    private var activeLocalMotor: String? = null
    private var pendingLocalMotor = "qwen"
    // Gemma e Qwen executam somente em um processo Android isolado (:localai).
    // Uma falha JNI (SIGILL/SIGSEGV) nesse processo não encerra a interface.
    private var qwenLoaded = false
    private var qwenBound = false
    private var qwenRequestActive = false
    private var pendingQwen: String? = null
    private var qwenRemote: Messenger? = null
    private val busy = AtomicBoolean(false)
    // Motor Gemma 3 LiteRT-LM usa outro processo e nunca partilha a RAM com o Qwen.
    private var gemma3Remote: Messenger? = null
    private var gemma3Bound = false
    private var gemma3Active = false
    private var gemma3Pending: String? = null
    private val gemma3Replies by lazy {
        Messenger(Handler(Looper.getMainLooper()) { msg ->
            val txt = msg.data.getString("text").orEmpty()
            when (msg.what) {
                QwenWorkerService.EVENT_INFO -> event("info", txt)
                QwenWorkerService.EVENT_LOADED -> {
                    activeLocalMotor = "gemma3"
                    event("modelo", txt)
                    event("estado", "", snapshot())
                }
                QwenWorkerService.EVENT_RESULT -> {
                    gemma3Active = false; busy.set(false); event("resposta", txt)
                }
                QwenWorkerService.EVENT_ERROR -> {
                    gemma3Active = false; busy.set(false); event("erro", txt)
                }
                QwenWorkerService.EVENT_STREAM -> event("fluxo", txt)
            }
            true
        })
    }
    private val gemma3Connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            gemma3Remote = Messenger(binder)
            sendGemma3Pending()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            gemma3Remote = null
            if (activeLocalMotor == "gemma3") activeLocalMotor = null
            if (gemma3Bound) {
                runCatching { unbindService(this) }
                gemma3Bound = false
            }
            if (gemma3Active) {
                gemma3Active = false
                gemma3Pending = null
                busy.set(false)
                event("erro", "Motor Gemma 3 foi encerrado pelo Android; Jarvis continua aberto.")
            }
        }
        override fun onBindingDied(name: ComponentName?) = onServiceDisconnected(name)
    }
    private val qwenReplies by lazy {
        Messenger(Handler(Looper.getMainLooper()) { msg ->
            val txt = msg.data.getString("text").orEmpty()
            when (msg.what) {
                QwenWorkerService.EVENT_INFO -> event("info", txt)
                QwenWorkerService.EVENT_LOADED -> {
                    qwenLoaded = true
                    activeLocalMotor = pendingLocalMotor
                    event("modelo", "${if (activeLocalMotor == "gemma") "Gemma 4 E2B" else "Qwen"} carregado no Android (processo isolado).")
                    event("estado", "", snapshot())
                }
                QwenWorkerService.EVENT_STREAM -> event("fluxo", txt)
                QwenWorkerService.EVENT_RESULT -> {
                    qwenRequestActive = false; busy.set(false)
                    event("resposta", txt)
                }
                QwenWorkerService.EVENT_ERROR -> {
                    qwenRequestActive = false; busy.set(false)
                    event("erro", txt)
                }
            }
            true
        })
    }
    private val qwenConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            qwenRemote = Messenger(binder)
            sendPendingQwen()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            qwenRemote = null
            qwenLoaded = false
            activeLocalMotor = null
            if (qwenBound) {
                try { unbindService(this) } catch (_: Exception) { }
                qwenBound = false
            }
            if (qwenRequestActive) failQwen("O motor local parou. A interface continuou aberta. Escolha Qwen ou confira a memória/GPU.")
        }
        override fun onBindingDied(name: ComponentName?) {
            onServiceDisconnected(name)
        }
    }
    private var tts: TextToSpeech? = null
    private var adbService: IAdbService? = null
    private var adbBound = false
    private val adbActions = setOf("modelo", "android", "aplicativos", "tela", "inicio", "voltar")

    // V3.3: abrir apps comuns usando Intents Android; nao usa ADB, Shizuku ou root.
    private data class AppEntry(val name: String, val packageName: String)

    private fun normalizedAppName(value: String): String =
        Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace(Regex("[^a-z0-9]+"), " ").trim()

    @Suppress("DEPRECATION")
    private fun launchableApps(): List<AppEntry> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found: List<ResolveInfo> = packageManager.queryIntentActivities(intent, 0)
        return found.mapNotNull { info ->
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == packageName || !info.activityInfo.exported) return@mapNotNull null
            AppEntry(info.loadLabel(packageManager).toString().ifBlank { pkg }, pkg)
        }.distinctBy { it.packageName }.sortedBy { normalizedAppName(it.name) }
    }

    // Um nome reconhecido pelo usuario e resolvido contra apps instalados, nao executa comandos.
    private fun openLaunchableApp(requested: String) {
        val name = requested.trim().take(80)
        if (name.isEmpty()) { event("app", "Diga qual aplicativo deseja abrir."); return }
        val key = normalizedAppName(name)
        val preferred = mapOf(
            "youtube" to "com.google.android.youtube",
            "youtube music" to "com.google.android.apps.youtube.music",
            "whatsapp" to "com.whatsapp",
            "whatsapp business" to "com.whatsapp.w4b",
            "chrome" to "com.android.chrome",
            "google chrome" to "com.android.chrome",
            "spotify" to "com.spotify.music",
            "instagram" to "com.instagram.android",
            "telegram" to "org.telegram.messenger",
            "facebook" to "com.facebook.katana"
        )[key]
        val apps = launchableApps()
        val match = apps.firstOrNull { it.packageName == preferred }
            ?: apps.firstOrNull { normalizedAppName(it.name) == key }
            ?: run {
                val partial = apps.filter { normalizedAppName(it.name).startsWith(key) }
                if (partial.size == 1) partial.first() else null
            }
        if (match == null) {
            event("app", "Não encontrei um aplicativo chamado '$name'. Abra Android → Aplicativos para conferir os nomes disponíveis.")
            return
        }
        try {
            val launch = packageManager.getLaunchIntentForPackage(match.packageName)
            if (launch == null) { event("app", "O Android não permite abrir ${match.name} por esse atalho."); return }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            event("app", "Abrindo ${match.name}...")
            startActivity(launch)
        } catch (_: Exception) {
            event("app", "Não foi possível abrir ${match.name} neste aparelho.")
        }
    }

    private fun publishApps() {
        val list = JSONArray()
        launchableApps().take(300).forEach {
            list.put(JSONObject().put("nome", it.name).put("pacote", it.packageName))
        }
        event("aplicativos", "", JSONObject().put("items", list))
    }


    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        event("adb", if (result == PackageManager.PERMISSION_GRANTED) "Permissão autorizada. Toque novamente na ação." else "Permissão Shizuku negada.")
    }
    private val adbConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            adbService = IAdbService.Stub.asInterface(binder)
            adbBound = true
            event("adb", "Shizuku conectado: comandos ADB permitidos disponíveis.")
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            adbBound = false
            adbService = null
            event("adb", "Shizuku desconectado.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 13, 19)
        window.navigationBarColor = android.graphics.Color.rgb(9, 13, 19)
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(9, 13, 19))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) = loader.shouldInterceptRequest(request.url)
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                    request.url.toString() != "https://appassets.androidplatform.net/assets/index.html"
            }
            addJavascriptInterface(Bridge(), "JarvisAndroid")
            loadUrl("https://appassets.androidplatform.net/assets/index.html")
        }
        setContentView(web)
        try { Shizuku.addRequestPermissionResultListener(shizukuListener) } catch (_: Exception) { }
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("pt", "BR")
        }
    }

    private fun event(type: String, message: String, extra: JSONObject? = null) {
        val obj = JSONObject().put("type", type).put("message", message)
        if (extra != null) obj.put("data", extra)
        val payload = JSONObject.quote(obj.toString())
        runOnUiThread { web.evaluateJavascript("window.jarvisNative($payload)", null) }
    }

    private fun snapshot(): JSONObject {
        val memory = (getSystemService(ACTIVITY_SERVICE) as ActivityManager).let {
            val info = ActivityManager.MemoryInfo(); it.getMemoryInfo(info)
            JSONObject().put("total", info.totalMem).put("livre", info.availMem)
                .put("percent", ((info.totalMem - info.availMem) * 100.0 / info.totalMem).toInt())
        }
        val stat = StatFs(filesDir.absolutePath)
        val total = stat.totalBytes; val free = stat.availableBytes
        val battery = (getSystemService(BATTERY_SERVICE) as BatteryManager)
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return JSONObject()
            .put("ram", memory)
            .put("armazenamento", JSONObject().put("total", total).put("livre", free).put("percent", ((total - free) * 100.0 / total).toInt()))
            .put("bateria", battery)
            .put("modelos", JSONObject()
                .put("gemma", JSONObject().put("importado", modelFile("gemma").length() >= 16L * 1024 * 1024)
                    .put("tamanhoMB", modelFile("gemma").length() / 1048576))
                .put("qwen", JSONObject().put("importado", modelFile("qwen").length() >= 16L * 1024 * 1024)
                    .put("tamanhoMB", modelFile("qwen").length() / 1048576))
                .put("gemma3", JSONObject().put("importado", modelFile("gemma3").length() >= 100L * 1024 * 1024)
                    .put("tamanhoMB", modelFile("gemma3").length() / 1048576)))
            .put("motorLocalCarregado", if (qwenLoaded) activeLocalMotor else JSONObject.NULL)
            .put("shizuku", adbBound)
            .put("chaveDeepSeek", getApiKey().isNotBlank())
            .put("tarefas", JSONArray(prefs.getString("tarefas", "[]")))
            .put("notas", JSONArray(prefs.getString("notas", "[]")))
    }

    inner class Bridge {
        @JavascriptInterface fun abrirAplicativo(nome: String) = runOnUiThread {
            if (nome.length > 80) event("app", "Nome de aplicativo inválido.")
            else openLaunchableApp(nome)
        }
        @JavascriptInterface fun listarAplicativos() = runOnUiThread { publishApps() }
        @JavascriptInterface fun status() { event("estado", "", snapshot()) }
        @JavascriptInterface fun selecionarModelo(motor: String) = runOnUiThread {
            if (motor !in setOf("gemma3", "gemma", "qwen")) { event("erro", "Modelo não reconhecido."); return@runOnUiThread }
            if (busy.get()) { event("erro", "Aguarde a resposta atual antes de importar modelos."); return@runOnUiThread }
            val it = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            startActivityForResult(it, when (motor) { "gemma3" -> 1005; "gemma" -> 1004; else -> 1001 })
        }
        @JavascriptInterface fun selecionarArquivo() = runOnUiThread {
            val it = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            startActivityForResult(it, 1002)
        }
        @JavascriptInterface fun ouvir() = runOnUiThread {
            try {
                val it = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                startActivityForResult(it, 1003)
            } catch (_: Exception) { event("erro", "Reconhecimento de voz indisponível neste aparelho.") }
        }
        @JavascriptInterface fun falar(texto: String) = runOnUiThread {
            tts?.speak(texto.take(1000), TextToSpeech.QUEUE_FLUSH, null, "jarvis-fala")
        }
        @JavascriptInterface fun definirChave(chave: String) {
            try {
                if (chave.isBlank()) { prefs.edit().remove("apiSecret").remove("apiIv").apply(); event("info", "Chave removida.") }
                else { saveApiKey(chave.trim()); event("info", "Chave DeepSeek guardada no Android Keystore.") }
                event("estado", "", snapshot())
            } catch (_: Exception) { event("erro", "Falha ao proteger a chave da API.") }
        }
        @JavascriptInterface fun salvar(tipo: String, raw: String) {
            if (tipo !in setOf("tarefas", "notas") || raw.length > 150000) return
            try {
                val arr = JSONArray(raw)
                if (arr.length() > 200) throw IllegalArgumentException()
                prefs.edit().putString(tipo, arr.toString()).apply()
                event("estado", "", snapshot())
            } catch (_: Exception) { event("erro", "Dados inválidos para salvar.") }
        }
        @JavascriptInterface fun perguntar(modo: String, pergunta: String) {
            val txt = pergunta.trim()
            if (txt.isEmpty() || txt.length > 1500) { event("erro", "Mensagem inválida (máx. 1500 caracteres)."); return }
            if (modo !in setOf("gemma3", "gemma", "qwen", "deepseek")) { event("erro", "Motor de IA inválido."); return }
            if (modo != "deepseek") {
                val reason = localPreflight(modo)
                if (reason != null) { event("erro", reason); return }
            }
            if (!busy.compareAndSet(false, true)) { event("erro", "Aguarde a resposta anterior."); return }
            if (modo == "deepseek") {
                runOnUiThread { stopGemma3Worker(); stopQwenWorker() }
                scope.launch {
                    try { event("resposta", deepSeek(txt)) }
                    catch (e: Exception) { event("erro", "DeepSeek: " + safeError(e)) }
                    finally { busy.set(false) }
                }
            } else if (modo == "gemma3") {
                runOnUiThread { stopQwenWorker(); startGemma3Request(txt) }
            } else {
                runOnUiThread { stopGemma3Worker(); startQwenRequest(modo, txt) }
            }
        }
        @JavascriptInterface fun solicitarAdb(acao: String) = runOnUiThread {
            if (acao !in adbActions) { event("erro", "Ação ADB bloqueada."); return@runOnUiThread }
            val confirmation = if (acao == "inicio" || acao == "voltar") "Isso mudará a tela do Android." else "Isso consultará dados do seu aparelho."
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Autorizar comando ADB: $acao?")
                .setMessage(confirmation + " O comando só será executado após sua confirmação.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Executar") { _, _ -> doAdb(acao) }
                .show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        if (requestCode == 1003) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
            event("voz", text)
        } else if (requestCode == 1002) {
            val uri = data?.data ?: return
            val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) c.getString(i) else null
            } ?: "Arquivo selecionado"
            event("arquivo", "Selecionado: $name (sem leitura automática)")
        } else if (requestCode == 1001 || requestCode == 1004 || requestCode == 1005) {
            val uri = data?.data ?: return
            val motor = when (requestCode) { 1004 -> "gemma"; 1005 -> "gemma3"; else -> "qwen" }
            val label = when (motor) { "gemma" -> "Gemma 4 E2B"; "gemma3" -> "Gemma 3 1B"; else -> "Qwen 1.5B" }
            val isLiteRT = motor == "gemma3"
            scope.launch {
                event("modelo", "Importando $label para o armazenamento privado...")
                try {
                    val size = withContext(Dispatchers.IO) {
                        val dst = File(filesDir, "$motor.tmp")
                        try {
                            contentResolver.openInputStream(uri)?.use { input ->
                                dst.outputStream().use { output -> input.copyTo(output, 256 * 1024) }
                            } ?: error("Não foi possível abrir o modelo.")
                            if (isLiteRT) {
                                val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
                                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                                    if (i >= 0 && c.moveToFirst()) c.getString(i) else null
                                }.orEmpty()
                                if (!name.endsWith(".litertlm", ignoreCase = true))
                                    error("Para Gemma 3 selecione o arquivo .litertlm, não GGUF ou .task.")
                            } else {
                                dst.inputStream().use { stream ->
                                    val magic = ByteArray(4)
                                    if (stream.read(magic) != 4 || String(magic, StandardCharsets.US_ASCII) != "GGUF") error("O arquivo não é um modelo GGUF.")
                                }
                            }
                            val output = modelFile(motor)
                            // Nunca apague o GGUF anterior se a cópia estiver incompleta.
                            if (dst.length() < (if (isLiteRT) 100L * 1024 * 1024 else 16L * 1024 * 1024))
                                error("Arquivo de modelo incompleto.")
                            if (output.exists() && !output.delete()) error("Não foi possível substituir o GGUF antigo.")
                            if (!dst.renameTo(output)) error("Não foi possível mover o modelo.")
                            output.length() / 1048576
                        } finally { dst.delete() }
                    }
                    stopGemma3Worker()
                    stopQwenWorker()
                    event("modelo", "$label importado ($size MB). Selecione a IA no Chat.")
                    event("estado", "", snapshot())
                } catch (e: Exception) { event("erro", "Importação: " + safeError(e)) }
            }
        }
    }

    // Conservador: a carga nativa não pode ser recuperada se o Android matar o processo por RAM.
    private fun localPreflight(motor: String): String? {
        val label = when (motor) { "gemma3" -> "Gemma 3 1B"; "gemma" -> "Gemma 4 E2B"; else -> "Qwen" }
        val model = modelFile(motor)
        val format = if (motor == "gemma3") ".litertlm" else "GGUF"
        if (!model.isFile) return "$label: importe primeiro o arquivo $format em Configurações."
        val size = model.length()
        if (size < (if (motor == "gemma3") 100L * 1024 * 1024 else 16L * 1024 * 1024))
            return "$label: arquivo incompleto. Importe novamente."
        val mem = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mem)
        // Gemma via Vulkan carrega a maior parte dos pesos na RAM/GPU compartilhada.
        val required = when (motor) {
            "gemma" -> size + 384L * 1024 * 1024
            "gemma3" -> size + 768L * 1024 * 1024
            else -> (size * 1.10 + 256.0 * 1024 * 1024).toLong()
        }
        // Na troca de IAs, o serviço libera o GGUF anterior antes de carregar o novo.
        if (mem.availMem < required && (activeLocalMotor == null || activeLocalMotor == motor))
            return "$label: RAM livre insuficiente. Feche outros aplicativos ou selecione Qwen."
        return null
    }


    private fun startGemma3Request(prompt: String) {
        gemma3Pending = prompt
        gemma3Active = true
        if (gemma3Remote != null) { sendGemma3Pending(); return }
        if (!gemma3Bound) {
            try {
                gemma3Bound = bindService(Intent(this, Gemma3WorkerService::class.java), gemma3Connection, Context.BIND_AUTO_CREATE)
                if (!gemma3Bound) {
                    gemma3Active = false; busy.set(false)
                    event("erro", "Não foi possível iniciar Gemma 3 em CPU.")
                }
            } catch (e: Exception) {
                gemma3Bound = false; gemma3Active = false; busy.set(false)
                event("erro", "Gemma 3: " + safeError(e))
            }
        }
    }

    private fun sendGemma3Pending() {
        val prompt = gemma3Pending ?: return
        val worker = gemma3Remote ?: return
        gemma3Pending = null
        val request = Message.obtain(null, QwenWorkerService.REQUEST_CHAT)
        request.data = Bundle().apply { putString("text", prompt) }
        request.replyTo = gemma3Replies
        try { worker.send(request) } catch (e: RemoteException) {
            gemma3Remote = null; gemma3Active = false; busy.set(false)
            event("erro", "Gemma 3 não respondeu: " + safeError(e))
        }
    }

    private fun stopGemma3Worker() {
        gemma3Pending = null
        gemma3Active = false
        if (activeLocalMotor == "gemma3") activeLocalMotor = null
        if (gemma3Bound) {
            runCatching { unbindService(gemma3Connection) }
            gemma3Bound = false
        }
        gemma3Remote = null
    }

    private fun failQwen(message: String) {
        pendingQwen = null
        qwenRequestActive = false
        busy.set(false)
        event("erro", "IA local: $message")
    }

    private fun startQwenRequest(motor: String, text: String) {
        pendingLocalMotor = motor
        qwenRequestActive = true
        pendingQwen = text
        if (qwenRemote != null) { sendPendingQwen(); return }
        if (!qwenBound) {
            try {
                qwenBound = bindService(Intent(this, QwenWorkerService::class.java), qwenConnection, Context.BIND_AUTO_CREATE)
                if (!qwenBound) failQwen("Não foi possível iniciar o serviço local.")
            } catch (e: Exception) {
                qwenBound = false
                failQwen("Falha ao abrir processo da IA local: " + safeError(e))
            }
        }
    }

    private fun sendPendingQwen() {
        val prompt = pendingQwen ?: return
        val worker = qwenRemote ?: return
        pendingQwen = null
        val request = Message.obtain(null, QwenWorkerService.REQUEST_CHAT)
        request.data = Bundle().apply { putString("text", prompt); putString("motor", pendingLocalMotor) }
        request.replyTo = qwenReplies
        try { worker.send(request) }
        catch (e: RemoteException) {
            qwenRemote = null
            qwenLoaded = false
            failQwen("O processo local não respondeu: " + safeError(e))
        }
    }

    private fun stopQwenWorker() {
        qwenLoaded = false
        activeLocalMotor = null
        pendingQwen = null
        if (qwenBound) {
            try { unbindService(qwenConnection) } catch (_: Exception) { }
            qwenBound = false
        }
        qwenRemote = null
        // Um serviço bound-only termina quando não há mais clientes.
    }

    private suspend fun deepSeek(msg: String): String = withContext(Dispatchers.IO) {
        val secret = getApiKey()
        if (secret.isBlank()) throw IllegalStateException("Adicione sua chave DeepSeek em Configurações.")
        val payload = JSONObject().put("model", "deepseek-flash")
            .put("thinking", JSONObject().put("type", "disabled"))
            .put("stream", false).put("max_tokens", 650)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", "Você é Jarvis, assistente em português. Responda apenas texto; não execute ações nem solicite dados pessoais."))
                .put(JSONObject().put("role", "user").put("content", msg)))
        val conn = (URL("https://api.deepseek.com/chat/completions").openConnection() as HttpURLConnection)
        try {
            conn.requestMethod = "POST"; conn.connectTimeout = 15000; conn.readTimeout = 65000
            conn.setRequestProperty("Authorization", "Bearer $secret")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            conn.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
            if (conn.responseCode != 200) throw IllegalStateException("HTTP ${conn.responseCode}. Confira a chave, saldo e conexão.")
            val body = conn.inputStream.bufferedReader().use { it.readText().take(250000) }
            JSONObject(body).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").take(12000)
        } finally { conn.disconnect() }
    }

    private fun doAdb(action: String) {
        try {
            if (!Shizuku.pingBinder()) { event("erro", "Instale e inicie o Shizuku via Depuração sem fio para usar comandos ADB."); return }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(4544)
                event("adb", "Autorize o Jarvis no Shizuku e toque na ação novamente.")
                return
            }
            if (adbService == null) {
                val args = Shizuku.UserServiceArgs(ComponentName(this, AdbShellService::class.java))
                    .daemon(false).processNameSuffix("jarvis_adb").debuggable(false).version(1)
                Shizuku.bindUserService(args, adbConnection)
                event("adb", "Conectando serviço ADB. Toque novamente na ação após conectar.")
                return
            }
            scope.launch(Dispatchers.IO) {
                try { event("adb", adbService!!.executar(action).take(30000)) }
                catch (e: Exception) { event("erro", "ADB falhou: " + safeError(e)) }
            }
        } catch (_: Exception) { event("erro", "Shizuku não está disponível ou não iniciou.") }
    }

    private fun keyStoreKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getKey("jarvis_deepseek", null) as? SecretKey
        if (existing != null) return existing
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").run {
            init(KeyGenParameterSpec.Builder("jarvis_deepseek", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
            generateKey()
        }
    }
    private fun saveApiKey(secret: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, keyStoreKey())
        val ciphertext = cipher.doFinal(secret.toByteArray(StandardCharsets.UTF_8))
        prefs.edit().putString("apiSecret", Base64.encodeToString(ciphertext, Base64.NO_WRAP))
            .putString("apiIv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP)).apply()
    }
    private fun getApiKey(): String {
        return try {
            val secret = prefs.getString("apiSecret", null) ?: return ""
            val iv = prefs.getString("apiIv", null) ?: return ""
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, keyStoreKey(), GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
            String(cipher.doFinal(Base64.decode(secret, Base64.NO_WRAP)), StandardCharsets.UTF_8)
        } catch (_: Exception) { "" }
    }

    private fun safeError(e: Throwable): String = when (e) {
        is OutOfMemoryError -> "Memória insuficiente. Experimente um Qwen quantizado menor."
        else -> (e.message ?: e.javaClass.simpleName).take(240).replace(Regex("sk-[\\w-]+"), "[chave oculta]")
    }
    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(shizukuListener) } catch (_: Exception) { }
        qwenRequestActive = false
        stopGemma3Worker()
        stopQwenWorker()
        scope.cancel()
        tts?.stop(); tts?.shutdown()
        web.removeJavascriptInterface("JarvisAndroid")
        web.destroy()
        super.onDestroy()
    }
}
