package br.com.jarvislab.autonomo

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.RemoteException
import android.util.Log
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Gemma 3 1B (arquivo .litertlm) em CPU, totalmente separado da interface e do llama.kt.
 * O processo :gemma3ai protege o Jarvis caso a biblioteca nativa falhe.
 * As operações de Engine/Conversation são serializadas em uma única thread.
 */
class Gemma3WorkerService : Service() {
    private val executor = Executors.newSingleThreadExecutor { task -> Thread(task, "jarvis-gemma3-cpu") }
    private val dispatcher = executor.asCoroutineDispatcher()
    private val scope = CoroutineScope(SupervisorJob() + dispatcher)
    private val busy = AtomicBoolean(false)
    private var engine: Engine? = null
    private var conversation: Conversation? = null

    private fun notify(reply: Messenger, kind: Int, text: String) {
        val response = Message.obtain(null, kind)
        response.data = Bundle().apply { putString("text", text.take(12000)) }
        try { reply.send(response) } catch (_: RemoteException) { }
    }

    private val incoming by lazy {
        Messenger(Handler(Looper.getMainLooper()) { request ->
            if (request.what != QwenWorkerService.REQUEST_CHAT) return@Handler true
            val reply = request.replyTo ?: return@Handler true
            val prompt = request.data.getString("text").orEmpty().trim()
            if (prompt.isEmpty() || prompt.length > 1500) {
                notify(reply, QwenWorkerService.EVENT_ERROR, "Mensagem inválida.")
                return@Handler true
            }
            if (!busy.compareAndSet(false, true)) {
                notify(reply, QwenWorkerService.EVENT_ERROR, "Gemma 3 está respondendo. Aguarde.")
                return@Handler true
            }
            scope.launch {
                try { answer(prompt, reply) }
                finally { busy.set(false) }
            }
            true
        })
    }

    override fun onBind(intent: Intent?): IBinder = incoming.binder

    private suspend fun answer(prompt: String, reply: Messenger) {
        try {
            val file = File(filesDir, "gemma3_1b.litertlm")
            if (!file.isFile || file.length() < 100L * 1024 * 1024) {
                notify(reply, QwenWorkerService.EVENT_ERROR, "Gemma 3 1B: importe o modelo .litertlm primeiro.")
                return
            }
            if (engine == null) {
                notify(reply, QwenWorkerService.EVENT_INFO, "Iniciando Gemma 3 1B em CPU; nenhum ADB necessário...")
                val created = Engine(EngineConfig(modelPath = file.absolutePath, backend = Backend.CPU()))
                // LiteRT-LM exige inicialização fora do thread principal do Android.
                created.initialize()
                engine = created
                conversation = created.createConversation()
                notify(reply, QwenWorkerService.EVENT_LOADED, "Gemma 3 1B carregado em CPU.")
            }
            // O SDK mantém o contexto em Conversation; não duplicar histórico manualmente.
            val result = conversation!!.sendMessage(prompt).text.orEmpty().trim()
            if (result.isEmpty()) error("O modelo não retornou texto.")
            notify(reply, QwenWorkerService.EVENT_RESULT, result)
        } catch (t: Throwable) {
            Log.e("JarvisGemma3", "Erro no motor LiteRT-LM CPU", t)
            val info = when (t) {
                is OutOfMemoryError -> "Gemma 3 1B: sem memória RAM. Feche outros aplicativos e tente novamente."
                else -> "Gemma 3 1B (CPU): ${t.message ?: t.javaClass.simpleName}"
            }
            notify(reply, QwenWorkerService.EVENT_ERROR, info.take(300))
        }
    }

    override fun onDestroy() {
        // Fechamento no mesmo executor que criou os objetos nativos.
        runBlocking(dispatcher) {
            runCatching { conversation?.close() }
            conversation = null
            runCatching { engine?.close() }
            engine = null
        }
        dispatcher.close()
        super.onDestroy()
    }
}
