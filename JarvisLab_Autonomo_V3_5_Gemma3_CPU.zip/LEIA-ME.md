# JARVIS LAB V3.5 — Gemma 3 1B LiteRT-LM em CPU

Projeto-fonte experimental Android para gerar um APK pelo GitHub Actions. **Ainda não compilado nem testado em aparelho nesta entrega.** O APK não está incluído no ZIP.

## Modelos / compatibilidade

- **Gemma 3 1B IT em CPU**, motor oficial `com.google.ai.edge.litertlm:litertlm-android:0.16.1`, modelo **`gemma3-1b-it-int4.litertlm`**, aproximadamente 584 MB. Um processo isolado `:gemma3ai` protege a interface contra erro nativo. O arquivo deve ser importado separadamente via Configurações. Este é o modelo usado no Google AI Edge Gallery (formato LiteRT-LM, **não GGUF**).
- Qwen 1.5B em GGUF via `llama.kt`, CPU ARMv8-a, processo `:localai` — baseado na V3.4.
- Gemma 4 E2B em GGUF via `llama.kt`, GPU experimental — opcional, pode falhar por RAM insuficiente. Mantido como quarto motor opcional.
- DeepSeek via API HTTPS e chave guardada no Keystore Android.

Os dois motores de IA local são executados em processos distintos. O app desliga o serviço do modelo anterior quando um novo motor local é usado, para não manter modelos simultaneamente na RAM. A abertura direta de apps, o reconhecimento de voz do Android, notas e tarefas permanecem. Sem Termux, ADB ou Shizuku **para abrir aplicativos**. Shizuku continua opcional apenas para ações ADB avançadas.

**RAM:** mesmo sendo 584 MB no disco, Gemma 3 ainda pode ocupar mais RAM durante a inferência. A verificação de RAM do app exige ~584 MB + 768 MiB disponíveis; esse limite é uma proteção heurística, não garantia de execução.

**Modelo:** https://huggingface.co/litert-community/Gemma3-1B-IT/tree/main — selecione exatamente `gemma3-1b-it-int4.litertlm`. O repositório pode exigir aceitar a licença Gemma com uma conta Hugging Face. Não importe o arquivo `.task` ou um modelo GGUF no slot de Gemma 3. O modelo instalado dentro do Google AI Edge Gallery não pode ser lido diretamente por outro app; baixe/importar uma cópia independente.

## Compilar no GitHub

1. Adicione `JarvisLab_Autonomo_V3_5_Gemma3_CPU.zip` na **raiz** do mesmo repositório GitHub utilizado para V3.4 (não extrair no celular).
2. Crie o arquivo **`.github/workflows/build-jarvis-v35.yml`** com o workflow fornecido separadamente (ou extraia este arquivo do ZIP e faça upload).
3. No GitHub → Actions, execute **JARVIS V3.5 Gemma3 CPU + Qwen + DeepSeek** (branch main).
4. Se a execução concluir com sucesso, baixe o artefato `JarvisLab-V3.5-Gemma3-CPU-APK` e instale o APK.
5. A V3.5 usa novo applicationId `br.com.jarvislab.autonomo.v35`, então não sobrescreve a V3.4. Cada instalação armazena modelos e chave DeepSeek separadamente.
6. No Jarvis: **Mais → Configurações → Importar Gemma 3 .litertlm** → escolha o modelo e selecione "Gemma 3 1B • CPU" no Chat.

## Limitações honestas

- Requer download da biblioteca LiteRT-LM durante o build, além das dependências pré-existentes; `0.16.1` foi escolhida porque a documentação oficial informa compatibilidade com Kotlin 2.2.20. O build **precisa ser validado pelo GitHub**.
- Se LiteRT-LM falhar por falta de RAM, o serviço isolado pode parar; a interface deve continuar. Sem garantia de performance no Snapdragon 685.
- A V3.5 mantém Gemma 4, mas a prioridade de teste é o Gemma 3 CPU. Não tente carregar ambos em simultâneo.
- Voz para texto utiliza RecognizerIntent do Android, que pode depender de componentes e conexão externos; inferência Gemma 3 é local.
