# JARVIS LAB V3.6 — Gemma 3 + Qwen + DeepSeek | Memória + Voz

## Alterações em relação à V3.5

- Removido o Gemma 4 E2B: não aparece mais no seletor, nas configurações, no fluxo de importação ou no motor Qwen.
- Gemma 3 1B local no formato `.litertlm`, executado por LiteRT-LM 0.16.1 em CPU e processo Android isolado.
- Qwen 1.5B local em GGUF via llama.kt, processo isolado, ARMv8-A (sem `dotprod`).
- DeepSeek online por API HTTPS, com chave armazenada no Keystore Android.
- Memória de longa duração: guardar fatos por texto/voz com «Jarvis, lembre que...», e remover com «Jarvis, esqueça que...». Uma tela mostra todas as memórias com botão de exclusão.
- Últimas 30 mensagens ficam no histórico privado do aplicativo, disponíveis ao reabri-lo. Algumas mensagens recentes também são usadas como contexto inicial de um novo motor.
- Fatos da memória são introduzidos no contexto do modelo local, com limites para não esgotar o contexto.
- Privacidade: por padrão, DeepSeek NÃO recebe memória nem histórico guardados; opção explícita para incluir esse contexto nas requisições online.
- Voz: toque no microfone para reconhecer frases em português; qualquer frase reconhecida é enviada automaticamente; opção de resposta por voz com TextToSpeech; botão para ler a última resposta.
- Abertura de aplicativos nativos por voz ou texto, sem ADB/Shizuku. As funções ADB avançadas continuam opcionais e com confirmação.
- Tarefas, notas, arquivos e interface futurista preservados.

## Compilação no GitHub Actions

1. Envie `JarvisLab_Autonomo_V3_6_Memoria_Voz.zip` para a raiz do repositório `JarvisLab-Android`.
2. Envie `build-jarvis-v36.yml` para `.github/workflows/`.
3. Vá a Actions → `JARVIS V3.6 Memoria + Voz | Gemma3 + Qwen + DeepSeek` → `Run workflow`.
4. Se concluir em verde, abra o artefato `JarvisLab-V3.6-Memoria-Voz-APK`, baixe o ZIP, extraia e instale o APK.
5. Importar novamente o Gemma 3 `.litertlm` e/ou o Qwen GGUF na nova V3.6. A aplicação usa um ID distinto (`br.com.jarvislab.autonomo.v36`); a V3.5 permanece instalada separadamente.

## Testes

1. Selecione Gemma 3, importe `.litertlm`, diga «Olá Jarvis». Confirme resposta.
2. Toque no microfone, diga «Jarvis, abra o YouTube»: o Android deve abrir o app sem Shizuku.
3. Toque no microfone, diga «Jarvis, lembre que prefiro respostas curtas». Confira na tela Memória.
4. Feche e reabra a V3.6. Pergunte «Qual preferência você lembra?». Verifique se respondeu considerando a memória.
5. Ative «Responder falando quando eu usar o microfone» e faça outra pergunta por voz.
6. Teste Qwen GGUF e DeepSeek separadamente. As memórias não são enviadas ao DeepSeek salvo se ativar essa opção na tela Memória.
7. Teste apagar memória e histórico separadamente.

## Notas de funcionamento

- O reconhecimento de voz usa o serviço de fala disponível no Android (`RecognizerIntent`); ele pode exigir internet, mesmo com Gemma e Qwen offline. A preferência por reconhecimento offline não é garantia do Android.
- Não há escuta contínua nem palavra de ativação em segundo plano. O usuário toca no microfone para iniciar a escuta.
- Memória e histórico ficam nas preferências privadas do aplicativo, sem sincronização automática. Não são protegidos com criptografia própria; quem tiver acesso privilegiado ao aparelho pode extraí-los.
- A V3.6 ainda é código-fonte experimental: não há garantia de compilação ou funcionamento até executar o GitHub Actions e testar no celular.
- Novo APK de depuração gerado por GitHub Actions tem assinatura de depuração e pode não atualizar instalações assinadas por outros certificados, por isso foi usado novo applicationId.
