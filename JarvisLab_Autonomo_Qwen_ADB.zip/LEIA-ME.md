# JARVIS LAB Autônomo — Qwen Local + ADB (projeto beta)

**Este é o código-fonte Android, não um APK compilado.**

## Arquitetura

- Aplicativo Android nativo Kotlin/WebViewAssetLoader; não precisa de Termux, servidor Python ou endereço `127.0.0.1`.
- Painel circular grafite/prata, chat e barra de voz; botões da interface abrem áreas funcionais.
- Qwen local a partir de um arquivo **GGUF escolhido pelo usuário**, carregado via motor llama.kt/llama.cpp, sem enviar prompts à nuvem. O modelo não está incluído no ZIP e deve ser importado pelo sistema de arquivos do Android.
- DeepSeek opcional via HTTPS, modelo `deepseek-flash`. Requer internet, API key e saldo/uso permitido. Chave armazenada criptografada no Android Keystore, **não no APK nem no GitHub**.
- ADB avançado via API do Shizuku + UserService com comandos predefinidos. Requer instalar e ativar **Shizuku** (Depuração sem fio no Android 11+), conceder permissão e autorizar cada ação individualmente. Não requer Termux nem acesso root. Depois de reiniciar pode precisar ativar Shizuku novamente.
- Notas, tarefas, telemetria, seletor de arquivos, reconhecimento de voz e TTS via APIs Android.

## Limitações importantes

1. Qwen pode precisar de vários GB de espaço e RAM. Comece com um GGUF Qwen2.5 0.5B ou 1.5B quantizado Q4_K_M. Modelos 3B ou maiores podem ficar lentos/esgotar memória.
2. Qwen não controla ADB automaticamente. **Todas as ações ADB são explícitas**: o usuário abre Android, seleciona uma ação predefinida, confirma e concede Shizuku.
3. Este APK depende de Shizuku para ADB avançado, mas **não depende de Termux** para a interface e o Qwen.
4. As funções Python específicas da V90 não são convertidas automaticamente; esta é uma implementação nativa separada. Preserve o original.
5. A compilação nativa de llama.kt exige Android NDK, download de dependências e bastante memória do runner. O GitHub Actions abaixo é uma base de compilação ainda não executada neste ambiente.
6. A verificação do projeto inclui sintaxe HTML/JS e estrutura das fontes, mas **não houve compilação Android nem teste em dispositivo nesta sessão**.

## Como compilar pelo GitHub (repositório existente)

1. Envie **`JarvisLab_Autonomo_Qwen_ADB.zip`** à raiz do repositório `JarvisLab-Android` já criado. NÃO exclua o ZIP antigo.
2. No GitHub, crie o arquivo **`.github/workflows/build-autonomo.yml`** e cole o conteúdo do arquivo fornecido separadamente (ainda que exista uma cópia dentro do ZIP, ela não fica visível para Actions sem extração).
3. Confirme as alterações na branch `main`.
4. Vá em **Actions > Jarvis Autonomo Qwen ADB > Run workflow**.
5. Se der certo, baixe o artefato `JarvisLab-Autonomo-Qwen-ADB-APK` e extraia `app-debug.apk`.
6. Se houver falha, abra o passo vermelho e copie o erro para diagnóstico. **Não suponha sucesso sem status verde e artefato.**

### Preparação do celular

- Instale o APK, abra JARVIS LAB Autônomo e toque em **Configurações > Importar modelo GGUF**.
- Selecione seu modelo Qwen `.gguf` baixado pelo navegador ou salvo no aparelho. O aplicativo fará uma cópia para seu armazenamento privado; aguarde terminar e evite trocar de modelo durante uma resposta.
- Entre em **Chat** e escolha **Qwen local** para conversar sem internet.
- Para comandos ADB: instale e configure [Shizuku](https://shizuku.rikka.app/download/), habilite a depuração sem fio nas configurações do desenvolvedor, autorize o Jarvis no Shizuku e teste em **Android**.
- Para DeepSeek: em **Configurações** adicione a chave API. Não envie a chave para o GitHub.

### Licenças e dependências

- `llama.kt`/`llama.cpp`: consulte licenças dos respectivos repositórios na versão baixada pela automação.
- Shizuku API: licença MIT da biblioteca; este projeto não copia ícones do Shizuku.
- Implementação própria do app: exemplo de referência; revise e teste antes de publicar em loja.
