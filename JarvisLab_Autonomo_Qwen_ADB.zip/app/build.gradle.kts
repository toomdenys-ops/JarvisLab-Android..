plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "br.com.jarvislab.autonomo"
    compileSdk = 35
    defaultConfig {
        applicationId = "br.com.jarvislab.autonomo"
        minSdk = 29
        targetSdk = 35
        versionCode = 3
        versionName = "3.0-qwen-adb-beta"
        ndk { abiFilters += "arm64-v8a" }
    }
    buildFeatures { aidl = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}
kotlin { jvmToolchain(21) }

dependencies {
    implementation(project(":llama-kt"))
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
