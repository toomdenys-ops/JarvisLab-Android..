# JARVIS LAB V3.3 — Apps sem ADB

Esta versão evolui o código-fonte da V3.2 (Qwen em processo isolado).

## Novo
- Abra apps instalados com **“Jarvis, abra o YouTube”**, **“Abra o WhatsApp”**, **“Abrir Spotify”** por mensagem ou voz.
- Ação nativa Android com `PackageManager` e `Intent`, sem confirmação repetida, sem Termux, sem Shizuku e sem ADB para **abrir** aplicativos.
- Aba Android → **Abrir aplicativos sem ADB** lista apps com atividade LAUNCHER; toque para abrir.
- Sem permissão `QUERY_ALL_PACKAGES`, apenas `<queries>` para apps com launcher.
- DeepSeek, Qwen, arquivos, notas, tarefas e recursos anteriores mantidos; comandos avançados ADB/Shizuku seguem opcionais e sujeitos às suas permissões e confirmações.

## Limites
- Precisa do Jarvis **visível na tela** para iniciar apps normalmente. Android restringe abertura de telas a partir do segundo plano.
- Pode abrir aplicativos instalados com launcher; **não controla automaticamente telas internas, notificações, mensagens, pagamentos ou configurações protegidas**.
- Comando de abrir app é interpretado diretamente a partir de uma ordem explícita do usuário; não é executado a partir de textos livres retornados pelo Qwen.
- A V3.3 tem `applicationId` distinto para instalar sem substituir a V3.2; o GGUF precisará ser importado novamente.

## Como compilar
1. Envie `JarvisLab_Autonomo_V3_3_Apps_Sem_ADB.zip` à raiz do seu repositório privado.
2. Envie `.github/workflows/build-jarvis-v33.yml` do ZIP para o GitHub em `.github/workflows/build-jarvis-v33.yml`.
3. Acesse GitHub Actions → **JARVIS V3.3 Apps sem ADB** → Run workflow.
4. Baixe o artefato ZIP com o APK de debug e instale para testes.

Não há APK pré-compilado nem teste realizado em um aparelho real nesta entrega.
