package br.com.jarvislab.autonomo;
interface IAdbService {
  String executar(String acao);
}
