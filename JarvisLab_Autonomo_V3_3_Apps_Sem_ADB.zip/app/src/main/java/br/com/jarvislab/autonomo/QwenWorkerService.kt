package br.com.jarvislab.autonomo

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.RemoteException
import android.util.Log
import com.tensai.llamakt.ChatMessage
import com.tensai.llamakt.LlamaEngine
import com.tensai.llamakt.SamplingParams
import com.tensai.llamakt.chat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.io.File

/** Processo separado do WebView. Crashes JNI não derrubam MainActivity. */
class QwenWorkerService : Service() {
    companion object {
        const val REQUEST_CHAT = 1
        const val EVENT_INFO = 2
        const val EVENT_LOADED = 3
        const val EVENT_STREAM = 4
        const val EVENT_RESULT = 5
        const val EVENT_ERROR = 6
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var engine: LlamaEngine? = null
    private val history = mutableListOf<ChatMessage>()

    private fun send(reply: Messenger, kind: Int, text: String) {
        val response = Message.obtain(null, kind)
        response.data = Bundle().apply { putString("text", text.take(12000)) }
        try { reply.send(response) } catch (_: RemoteException) { }
    }

    private val incoming by lazy {
        Messenger(Handler(Looper.getMainLooper()) { message ->
            if (message.what != REQUEST_CHAT) return@Handler true
            val reply = message.replyTo ?: return@Handler true
            val text = message.data.getString("text").orEmpty()
            if (text.isBlank() || text.length > 1500) {
                send(reply, EVENT_ERROR, "Mensagem inválida.")
            } else {
                scope.launch { answer(text, reply) }
            }
            true
        })
    }

    override fun onBind(intent: Intent?): IBinder = incoming.binder

    private suspend fun answer(text: String, reply: Messenger) {
        try {
            val file = File(filesDir, "qwen.gguf")
            if (!file.isFile || file.length() < 16L * 1024 * 1024) {
                send(reply, EVENT_ERROR, "Importe primeiro um GGUF válido nas configurações.")
                return
            }
            if (engine == null) {
                send(reply, EVENT_INFO, "Carregando Qwen no processo isolado...")
                Log.i("JarvisQwen", "Worker CPU armv8 baseline; iniciando load nCtx=1024")
                val created = LlamaEngine()
                created.load(file.absolutePath, nGpuLayers = 0, nCtx = 1024, kvCacheType = "q8_0")
                engine = created
                send(reply, EVENT_LOADED, "Qwen pronto")
            }
            val conversation = history.takeLast(8) + ChatMessage("user", text)
            val output = StringBuilder()
            var lastSent = 0L
            engine!!.chat(conversation, SamplingParams(nPredict = 256), enableThinking = false).collect { token ->
                output.append(token)
                if (System.currentTimeMillis() - lastSent > 250) {
                    send(reply, EVENT_STREAM, output.toString())
                    lastSent = System.currentTimeMillis()
                }
            }
            val result = output.toString().trim()
            if (result.isBlank()) error("O modelo retornou resposta vazia.")
            history.add(ChatMessage("user", text))
            history.add(ChatMessage("assistant", result))
            if (history.size > 12) history.subList(0, history.size - 12).clear()
            send(reply, EVENT_RESULT, result)
        } catch (e: Exception) {
            Log.e("JarvisQwen", "Erro de processamento no processo separado", e)
            send(reply, EVENT_ERROR, (e.message ?: e.javaClass.simpleName).take(200))
        } catch (e: OutOfMemoryError) {
            Log.e("JarvisQwen", "RAM insuficiente no processo separado", e)
            send(reply, EVENT_ERROR, "Memória insuficiente. Use Qwen 0.5B Q4_K_M.")
        } catch (e: LinkageError) {
            Log.e("JarvisQwen", "Falha JNI no processo separado", e)
            send(reply, EVENT_ERROR, "Biblioteca nativa incompatível. Verifique o logcat.")
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
