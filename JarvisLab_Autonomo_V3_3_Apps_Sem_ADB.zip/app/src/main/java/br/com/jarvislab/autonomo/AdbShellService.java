package br.com.jarvislab.autonomo;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;

/** Shizuku UserService: runs as shell (ADB UID). NO arbitrary commands. */
public class AdbShellService extends IAdbService.Stub {
    public AdbShellService() {}

    @Override
    public String executar(String acao) {
        final String[] args;
        switch (acao) {
            case "modelo": args = new String[] {"getprop", "ro.product.model"}; break;
            case "android": args = new String[] {"getprop", "ro.build.version.release"}; break;
            case "aplicativos": args = new String[] {"pm", "list", "packages", "-3"}; break;
            case "tela": args = new String[] {"wm", "size"}; break;
            case "inicio": args = new String[] {"input", "keyevent", "3"}; break;
            case "voltar": args = new String[] {"input", "keyevent", "4"}; break;
            default: return "Ação ADB não permitida.";
        }
        Process p = null;
        try {
            p = new ProcessBuilder(args).redirectErrorStream(true).start();
            if (!p.waitFor(12, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                return "Tempo limite do comando ADB esgotado.";
            }
            try (InputStream in = p.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[1024]; int n;
                while ((n = in.read(buf)) >= 0 && out.size() < 30000) out.write(buf, 0, Math.min(n, 30000 - out.size()));
                String result = out.toString("UTF-8").trim();
                return "Código: " + p.exitValue() + "\n" + (result.isEmpty() ? "Comando executado." : result);
            }
        } catch (Exception e) {
            return "Comando falhou: " + e.getClass().getSimpleName();
        } finally {
            if (p != null) p.destroy();
        }
    }
}
