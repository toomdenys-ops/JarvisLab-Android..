package br.com.jarvislab.autonomo

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class JarvisCapsuleService : Service() {
    private var windowManager: WindowManager? = null
    private var capsule: View? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Settings.canDrawOverlays(this) && capsule == null) showCapsule()
        else if (!Settings.canDrawOverlays(this)) stopSelf()
        return START_STICKY
    }

    private fun showCapsule() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()

        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(7))
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(30, 46, 59), Color.rgb(13, 23, 33))
            ).apply {
                cornerRadius = dp(30).toFloat()
                setStroke(dp(1), Color.rgb(66, 174, 213))
            }
            contentDescription = "Cápsula flutuante do Jarvis. Toque para abrir a conversa por voz."
            elevation = dp(8).toFloat()
        }

        val logo = TextView(this).apply {
            text = "J"
            textSize = 19f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(34, 151, 190))
                setStroke(dp(1), Color.rgb(147, 221, 246))
            }
        }
        shell.addView(logo, LinearLayout.LayoutParams(dp(38), dp(38)))

        val labels = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(9), 0, dp(4), 0)
        }
        labels.addView(TextView(this).apply {
            text = "JARVIS"
            textSize = 12f
            letterSpacing = .18f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.rgb(232, 243, 248))
        })
        labels.addView(TextView(this).apply {
            text = "TOQUE PARA FALAR"
            textSize = 8f
            letterSpacing = .06f
            setTextColor(Color.rgb(128, 191, 216))
        })
        shell.addView(labels, LinearLayout.LayoutParams(dp(116), dp(38)))

        val close = TextView(this).apply {
            text = "×"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(170, 199, 213))
            contentDescription = "Fechar cápsula do Jarvis"
            isClickable = true
            setOnClickListener {
                getSharedPreferences("jarvis_data", MODE_PRIVATE).edit().putBoolean("capsuleEnabled", false).apply()
                stopSelf()
            }
        }
        shell.addView(close, LinearLayout.LayoutParams(dp(30), dp(38)))

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(10)
            y = dp(220)
        }

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0f
        var startY = 0f
        var originalX = 0
        var originalY = 0
        var dragged = false
        shell.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX
                    startY = event.rawY
                    originalX = params.x
                    originalY = params.y
                    dragged = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - startX
                    val dy = event.rawY - startY
                    if (kotlin.math.abs(dx) > touchSlop || kotlin.math.abs(dy) > touchSlop) dragged = true
                    if (dragged) {
                        val maxX = (resources.displayMetrics.widthPixels - dp(200)).coerceAtLeast(0)
                        val maxY = (resources.displayMetrics.heightPixels - dp(70)).coerceAtLeast(0)
                        params.x = (originalX - dx).toInt().coerceIn(0, maxX)
                        params.y = (originalY + dy).toInt().coerceIn(0, maxY)
                        runCatching { wm.updateViewLayout(shell, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) {
                        startActivity(Intent(this, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            putExtra("jarvis_capsule_voice", true)
                        })
                    }
                    true
                }
                else -> true
            }
        }

        try {
            wm.addView(shell, params)
            capsule = shell
        } catch (_: Exception) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        capsule?.let { view -> runCatching { windowManager?.removeView(view) } }
        capsule = null
        windowManager = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
