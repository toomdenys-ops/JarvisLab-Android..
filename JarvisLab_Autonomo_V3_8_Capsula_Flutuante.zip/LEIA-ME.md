# JARVIS LAB V3.8 — cápsula flutuante

Atualização da V3.7: adiciona uma cápsula grafite e azul que pode ficar por cima de outros aplicativos. Toque na cápsula para abrir o Jarvis na conversa por voz. Ela pode ser arrastada e fechada pelo botão ×.

## Recursos preservados

- Gemma 3 1B LiteRT-LM, Qwen 1.5B GGUF e DeepSeek HTTPS.
- Memória, histórico, notas, tarefas, acesso a arquivos e integrações Android já existentes.
- Seleção de vozes em português, teste e salvamento da voz escolhida.
- Mesmo `applicationId` da V3.7 e `versionCode` incrementado: a instalação como atualização mantém os dados privados da V3.7, incluindo modelos e preferências, desde que seja assinada com a mesma chave usada para aquela instalação.

## Primeira ativação

1. Instale a V3.8 sobre a V3.7.
2. Abra o Jarvis e entre em **Configurações**.
3. Toque em **Ativar cápsula**.
4. No Android, permita **Exibir sobre outros apps** para o JARVIS LAB e volte ao aplicativo.
5. Arraste a cápsula para a posição desejada. Toque nela para iniciar a conversa por voz.

A conversa por voz usa o reconhecedor que estiver disponível no Android. Para remover a cápsula, use **Desativar cápsula** ou toque no ×.

## Compilar o APK

O arquivo ZIP contém o código-fonte e o workflow, não um APK pronto. Envie `JarvisLab_Autonomo_V3_8_Capsula_Flutuante.zip` à raiz do repositório e use **Actions → JARVIS V3.8 Cápsula Flutuante → Run workflow**. Baixe o artefato `JarvisLab-V3.8-Capsula-Flutuante-APK` quando a compilação terminar.

A compilação e a execução em aparelho Android precisam ser confirmadas pelo workflow e instaladas no celular.
