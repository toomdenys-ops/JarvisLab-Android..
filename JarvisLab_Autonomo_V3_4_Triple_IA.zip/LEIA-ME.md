# JARVIS LAB V3.4 — Gemma 4 + Qwen 1.5B + DeepSeek

Esta é uma **versão experimental do código-fonte**, derivada da V3.3 que funcionou no celular. APK não incluído; compile via GitHub Actions.

## Três IAs no chat

- **Gemma 4 E2B — principal**, selecionada ao abrir o app. Importe GGUF oficial `gemma-4-E2B_q4_0-it.gguf` de https://huggingface.co/google/gemma-4-E2B-it-qat-q4_0-gguf/tree/main (~3,35 GB). Usa carga GPU/Vulkan *experimental* (`nGpuLayers=99`, `nCtx=1024`), não foi validada neste aparelho. Requer RAM e espaço de armazenamento elevados. Pode ficar lento, falhar na GPU ou encerrar somente o processo do modelo.
- **Qwen 1.5B — alternativa leve**, separadamente importado como GGUF e carregado no modo CPU, preservando as boas configurações da V3.3 (ARMv8-a + serviço isolado). Qualquer GGUF do modelo deve ser importado novamente neste novo pacote.
- **DeepSeek — online**; usa chave protegida no Keystore e HTTPS. Pode cobrar por requisição. A nova instalação não herda chaves antigas.

O serviço de IA funciona em um processo Android separado da interface. Ao trocar de Gemma para Qwen ou vice-versa, o modelo anterior é liberado para não tentar manter os dois na RAM. A memória de conversa é separada por IA durante o processo; não há ainda memória permanente do chat.

As ações de abrir aplicativos por voz ou texto usam Intents do Android, sem confirmação repetida nem ADB/Shizuku, quando o Jarvis está visível. Comandos ADB avançados continuam opcionais e exigem confirmação.

## Como compilar no GitHub

1. Faça upload de `JarvisLab_Autonomo_V3_4_Triple_IA.zip` na **raiz** do repositório GitHub existente; não precisa extrair no celular.
2. Crie `.github/workflows/build-jarvis-v34.yml` com o arquivo `.yml` fornecido separadamente.
3. GitHub → Actions → `JARVIS V3.4 3 Inteligencias` → Run workflow → branch main.
4. Baixe artifact `JarvisLab-V3.4-3-IAs-APK` (ZIP gerado pelo GitHub) e instale o APK. Este projeto usa `applicationId` novo (`br.com.jarvislab.autonomo.v34`) para não sobrescrever sua V3.3.
5. Em Configurações, importe GGUF do Gemma e do Qwen **separadamente**. Comece testando o Qwen para verificar a estabilidade, depois o Gemma.

## Limitações honestas

- O Gemma 4 E2B pode ser impraticável em CPU: o repositório `tensai-app/llama.kt` mediu mais de 420 s para o caminho CPU e cerca de 2 tokens/s com Vulkan em um outro aparelho (Mali-G68). Não há garantia de aceleração no seu GPU Adreno. Por isso é um teste e **não substitui** Qwen.
- Apenas texto no modelo local; o motor Kotlin atual não expõe multimodalidade do Gemma (áudio/imagens) diretamente. O reconhecimento de voz existente é a função do Android.
- O GGUF ocupa ~3,35 GB mais os dados do modelo no armazenamento privado, e a importação requer espaço suficiente para manter a origem e a cópia simultaneamente.
- Se a GPU não suportar o modelo, o processo isolado pode cair, mas a interface deverá permanecer aberta. O erro deve ser capturado via logcat para uma versão mais confiável.
- O APK não foi compilado nem testado no celular nesta entrega. A verificação presente é estática e de sintaxe.
