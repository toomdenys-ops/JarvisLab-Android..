# JARVIS LAB V3.2 — Qwen em processo Android isolado (beta)

**O V3.1 tinha o seguinte erro de logcat: `SIGILL (ILL_ILLOPC)` durante `LlamaEngine.load`.**

Esta revisão contém duas proteções complementares:

1. **Arquitetura ARM64 básica**: o workflow de compilação verifica e substitui exatamente um `-march=armv8.2-a+dotprod` por `-march=armv8-a` no CMake do llama.kt. Se esse trecho mudar, a compilação falha deliberadamente para evitar um APK com flags antigas.
2. **Processo isolado**: `QwenWorkerService.kt` carrega o Qwen em `android:process=":qwen"`, separado do WebView principal. O chat conversa com esse serviço por `Messenger`. Um SIGILL/SIGSEGV do motor pode ainda interromper a resposta, mas não deve encerrar a interface principal do Jarvis.

**Ainda não compilado nem testado em dispositivo Android nesta sessão.** A compilação exige GitHub Actions e a execução no seu aparelho determina se a correção funcionou.

## Gerar APK sem alterar o anterior

- Envie `JarvisLab_Autonomo_V3_2_Qwen_Isolado.zip` para a raiz do repositório.
- Envie `build-qwen-v32.yml` para `.github/workflows/`.
- Em Actions, selecione `JARVIS V3.2 Qwen Isolado ARM64` e execute em `main`.
- Baixe o artefato `JarvisLab-V3.2-Qwen-Isolado-APK` e extraia `app-debug.apk`.
- O identificador de app novo `br.com.jarvislab.autonomo.v32` instala ao lado da V3.1.
- Importe seu GGUF novamente: versões distintas não compartilham arquivos privados.

## O que permanece

DeepSeek HTTPS, Keystore, voz, tarefas, notas, Shizuku/ADB com confirmações, tela futurista e seletor Qwen/DeepSeek. Nenhum segredo deve ser incluído no GitHub.

## Diagnóstico pós-instalação

O modelo ainda pode falhar se houver erro do GGUF, de memória, de driver ou da biblioteca. Se isso acontecer, o app deverá exibir erro sem fechar. Para registrar o erro com ADB:

```
adb logcat -b crash -c
# reproduza o problema
adb logcat -b crash -d -v time | tail -n 100
```

Esta é uma versão de diagnóstico/compatibilidade; não garante que todos os aparelhos executem inferência local.
